<?php

namespace Config;

class Token
{
    public const JWT_SECRET_KEY = 'SkripsiDidin';
}