<?= $this->extend('template') ?>

<?= $this->section('content') ?>
    <div class="jumbotron">
        <h1 class="display-4">Welcome to the Admin Panel</h1>
        <p class="lead">Manage buses, tickets, orders, and users from this panel.</p>
    </div>
<?= $this->endSection() ?>
